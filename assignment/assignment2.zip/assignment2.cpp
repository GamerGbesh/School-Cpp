/*Name: Zeh Edmund Etonam
ID: 22077794*/


#include <iostream>
using namespace std;

int main(){
    string str;
    int count_uppercase = 0;
    int count_lowercase = 0;
    cout <<"Enter a string: ";
    getline(cin,str);

    for(int i= 0; i < str.length(); i++){
        if(isupper(str[i]))
        count_uppercase++;
        else if(islower(str[i]))
        count_lowercase++;
        
    }

    cout <<"There are " << count_uppercase <<" uppercase letter(s) in the string " << str <<".\n";
    cout <<"There are " << count_lowercase <<" lowrcase letter(s) in the string " << str <<".\n";

    return 0;
}